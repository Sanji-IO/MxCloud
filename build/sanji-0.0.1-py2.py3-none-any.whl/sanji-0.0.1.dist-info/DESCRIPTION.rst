Sanji Framework SDK (Python)
============================
.. image:: https://travis-ci.org/Sanji-IO/sanji.svg
    :target: https://travis-ci.org/Sanji-IO/sanji
    :alt: Build Status

.. image:: https://pypip.in/version/modem-cmd/badge.svg
    :target: https://pypi.python.org/pypi/modem-cmd/
    :alt: Latest Version

.. image:: https://coveralls.io/repos/Sanji-IO/sanji/badge.png?branch=develop
    :target: https://coveralls.io/r/Sanji-IO/sanji?branch=develop
    :alt: Coverage Status

Installation
------------
::

    pip install sanji

Quick Start
-----------
**Comming soon...**

License
-------

MIT


